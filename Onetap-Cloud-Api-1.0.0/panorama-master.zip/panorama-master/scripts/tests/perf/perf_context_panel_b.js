"use strict";


function OnLoadedB()
{
                       
}

function ButtonActivatedOther()
{
                                                                                                  
    $.GetContextPanel().Data().moo_();
}

                                                                                                    
                                           
                                                                                                    
(function ()
{
                      
})();


