  
                                        
                                                                 
                                                              
                                 
                               
  
                      


  
                                                
  
var g_ActiveTournamentInfo =
{
	eventid: 16,
	organization: 'star',
	location: 'berlin2019',
	itemid_sticker: 4653,
	stickerid_graffiti: 4143,
	itemid_pass: 4622,
	itemid_pack: 4627,
	itemid_charge: 4628,
};


  
                                                      
  
var g_ActiveTournamentTeams =
[
	           
	{
		teamid: 60,
		team: 'astr',
		itemid_sticker: 4629,
		stickerid_graffiti: 4119,
		team_group: 'legends',
	},
	       
	{
		teamid: 84,
		team: 'ence',
		itemid_sticker: 4630,
		stickerid_graffiti: 4120,
		team_group: 'legends',
	},
	       
	{
		teamid: 80,
		team: 'mibr',
		itemid_sticker: 4631,
		stickerid_graffiti: 4121,
		team_group: 'legends',
	},
	                
	{
		teamid: 12,
		team: 'navi',
		itemid_sticker: 4632,
		stickerid_graffiti: 4122,
		team_group: 'legends',
	},
	                    
	{
		teamid: 1,
		team: 'nip',
		itemid_sticker: 4633,
		stickerid_graffiti: 4123,
		team_group: 'legends',
	},
	            
	{
		teamid: 61,
		team: 'faze',
		itemid_sticker: 4634,
		stickerid_graffiti: 4124,
		team_group: 'legends',
	},
	              
	{
		teamid: 48,
		team: 'liq',
		itemid_sticker: 4635,
		stickerid_graffiti: 4125,
		team_group: 'legends',
	},
	            
	{
		teamid: 53,
		team: 'ren',
		itemid_sticker: 4636,
		stickerid_graffiti: 4126,
		team_group: 'legends',
	},
	                    
	{
		teamid: 3,
		team: 'col',
		itemid_sticker: 4637,
		stickerid_graffiti: 4127,
		team_group: 'challengers',
	},
	              
	{
		teamid: 25,
		team: 'hlr',
		itemid_sticker: 4638,
		stickerid_graffiti: 4128,
		team_group: 'challengers',
	},
	          
	{
		teamid: 75,
		team: 'avg',
		itemid_sticker: 4639,
		stickerid_graffiti: 4129,
		team_group: 'challengers',
	},
	             
	{
		teamid: 59,
		team: 'g2',
		itemid_sticker: 4640,
		stickerid_graffiti: 4130,
		team_group: 'challengers',
	},
	           
	{
		teamid: 89,
		team: 'vita',
		itemid_sticker: 4641,
		stickerid_graffiti: 4131,
		team_group: 'challengers',
	},
	                   
	{
		teamid: 86,
		team: 'gray',
		itemid_sticker: 4642,
		stickerid_graffiti: 4132,
		team_group: 'contenders',
	},
	              
	{
		teamid: 29,
		team: 'mss',
		itemid_sticker: 4643,
		stickerid_graffiti: 4133,
		team_group: 'contenders',
	},
	                
	{
		teamid: 90,
		team: 'forz',
		itemid_sticker: 4644,
		stickerid_graffiti: 4134,
		team_group: 'contenders',
	},
	      
	{
		teamid: 87,
		team: 'nrg',
		itemid_sticker: 4645,
		stickerid_graffiti: 4135,
		team_group: 'contenders',
	},
	        
	{
		teamid: 74,
		team: 'tyl',
		itemid_sticker: 4646,
		stickerid_graffiti: 4136,
		team_group: 'contenders',
	},
	        
	{
		teamid: 85,
		team: 'furi',
		itemid_sticker: 4647,
		stickerid_graffiti: 4137,
		team_group: 'contenders',
	},
	        
	{
		teamid: 91,
		team: 'cr4z',
		itemid_sticker: 4648,
		stickerid_graffiti: 4138,
		team_group: 'contenders',
	},
	               
	{
		teamid: 92,
		team: 'syma',
		itemid_sticker: 4649,
		stickerid_graffiti: 4139,
		team_group: 'contenders',
	},
	        
	{
		teamid: 68,
		team: 'nor',
		itemid_sticker: 4650,
		stickerid_graffiti: 4140,
		team_group: 'contenders',
	},
	              
	{
		teamid: 93,
		team: 'drea',
		itemid_sticker: 4651,
		stickerid_graffiti: 4141,
		team_group: 'contenders',
	},
	                     
	{
		teamid: 94,
		team: 'intz',
		itemid_sticker: 4652,
		stickerid_graffiti: 4142,
		team_group: 'contenders',
	},
];


  
                                                            
  
var g_ActiveTournamentCapsules =
[
	4654,                                
	4655,                                              
	4656,                                          
	4657,                                  
	4658,                                                
	4659,                                            
];

var g_ActiveTournamentPasses =
[
	g_ActiveTournamentInfo.itemid_pass,
	g_ActiveTournamentInfo.itemid_pack,
];


  
                                                  
  
